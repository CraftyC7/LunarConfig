## Version 0.1.1

- Removed accidental dependency on LobbyCompatability (oops)

## Version 0.1.0

- Initial Release